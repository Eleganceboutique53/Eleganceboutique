ÉLÉGANCE BOUTIQUE — VERSION PARTAGE AVEC IMAGE

1. Dans le dépôt GitHub Pages, remplace index.html par ce fichier.
2. Ajoute preview.jpg à la racine du dépôt, au même niveau que index.html.
3. Vérifie que l'adresse est : https://eleganceboutique53.github.io/Eleganceboutique/
4. Attends quelques minutes après publication avant de tester le partage WhatsApp.

Cette version ajoute les balises Open Graph et Twitter Card avec une URL ABSOLUE vers preview.jpg, afin que WhatsApp puisse récupérer la miniature du lien.
